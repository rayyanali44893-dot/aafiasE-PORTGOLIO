import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, GraduationCap, ChevronRight, Github, Mail, Linkedin } from 'lucide-react';
import { COMPETENCIES } from '../data';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const location = useLocation();

  const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);
  const closeSidebar = () => setIsSidebarOpen(false);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      {/* Navbar */}
      <header className="sticky top-0 z-50 bg-white border-b border-slate-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            {/* Logo / Brand */}
            <div className="flex items-center">
              <Link to="/" className="flex items-center gap-2" onClick={closeSidebar}>
                <div className="bg-medical-600 p-2 rounded-lg text-white">
                  <GraduationCap size={24} />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-slate-900 leading-tight">Aafia Sayyed</h1>
                  <p className="text-xs text-medical-600 font-medium tracking-wide">MBBS e-PORTFOLIO</p>
                </div>
              </Link>
            </div>

            {/* Desktop Nav */}
            <nav className="hidden md:flex space-x-8">
              <Link 
                to="/" 
                className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                  location.pathname === '/' 
                    ? 'border-medical-600 text-slate-900' 
                    : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                }`}
              >
                About Me
              </Link>
              {/* Dropdown Logic could go here, but for simplicity we list a few or just rely on the sidebar for deep nav */}
              <div className="relative group h-16 flex items-center">
                <button className="inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium text-slate-500 hover:text-slate-700 hover:border-slate-300">
                  Competencies
                </button>
                <div className="absolute top-16 left-0 w-64 bg-white border border-slate-200 shadow-lg rounded-b-lg p-2 hidden group-hover:block transition-all duration-200">
                  {COMPETENCIES.map((comp) => (
                    <Link
                      key={comp.id}
                      to={`/competency/${comp.id}`}
                      className="block px-4 py-2 text-sm text-slate-700 hover:bg-medical-50 hover:text-medical-700 rounded-md"
                    >
                      {comp.shortTitle}
                    </Link>
                  ))}
                </div>
              </div>
            </nav>

            {/* Mobile Menu Button */}
            <div className="flex items-center md:hidden">
              <button
                onClick={toggleSidebar}
                className="inline-flex items-center justify-center p-2 rounded-md text-slate-400 hover:text-slate-500 hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-medical-500"
              >
                {isSidebarOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex flex-1 max-w-7xl w-full mx-auto">
        {/* Sidebar (Desktop: Sticky, Mobile: Overlay) */}
        <aside 
          className={`
            fixed inset-y-0 left-0 z-40 w-64 bg-white border-r border-slate-200 transform transition-transform duration-300 ease-in-out md:translate-x-0 md:static md:block
            ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
          `}
        >
          <div className="h-full flex flex-col pt-20 md:pt-4 pb-4 px-4 overflow-y-auto">
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-4 px-2">
              Core Competencies
            </h3>
            <nav className="space-y-1">
              {COMPETENCIES.map((comp) => {
                const isActive = location.pathname === `/competency/${comp.id}`;
                return (
                  <Link
                    key={comp.id}
                    to={`/competency/${comp.id}`}
                    onClick={closeSidebar}
                    className={`
                      group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors
                      ${isActive 
                        ? 'bg-medical-50 text-medical-700' 
                        : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'}
                    `}
                  >
                    <comp.icon 
                      className={`mr-3 flex-shrink-0 h-5 w-5 ${isActive ? 'text-medical-600' : 'text-slate-400 group-hover:text-slate-500'}`} 
                    />
                    {comp.shortTitle}
                    {isActive && <ChevronRight className="ml-auto h-4 w-4 text-medical-400" />}
                  </Link>
                );
              })}
            </nav>

            <div className="mt-auto pt-8">
              <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
                <p className="text-xs text-slate-500 mb-2">Need to contact me?</p>
                <a href="mailto:aafia.student@uni.edu" className="text-sm font-medium text-medical-600 hover:text-medical-800 flex items-center gap-2">
                  <Mail size={14} /> Email Me
                </a>
              </div>
            </div>
          </div>
        </aside>

        {/* Overlay for mobile sidebar */}
        {isSidebarOpen && (
          <div 
            className="fixed inset-0 bg-slate-600 bg-opacity-75 z-30 md:hidden"
            onClick={closeSidebar}
          ></div>
        )}

        {/* Main Content */}
        <main className="flex-1 min-w-0 bg-white md:ml-0 shadow-sm border-r border-l border-slate-200">
          <div className="py-6">
            {children}
          </div>
        </main>
      </div>

      <footer className="bg-white border-t border-slate-200 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="md:flex md:items-center md:justify-between">
            <div className="flex justify-center md:order-2 space-x-6">
              <a href="#" className="text-slate-400 hover:text-slate-500">
                <span className="sr-only">LinkedIn</span>
                <Linkedin size={20} />
              </a>
              <a href="#" className="text-slate-400 hover:text-slate-500">
                <span className="sr-only">GitHub</span>
                <Github size={20} />
              </a>
            </div>
            <div className="mt-8 md:mt-0 md:order-1">
              <p className="text-center text-sm text-slate-500">
                &copy; {new Date().getFullYear()} Aafia Sayyed. MBBS Student Portfolio.
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;