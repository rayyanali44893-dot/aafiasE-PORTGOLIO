import React from 'react';
import { useParams, Navigate } from 'react-router-dom';
import { COMPETENCIES } from '../data';
import { FileText, CheckCircle2, Quote, Paperclip, ImageIcon, Award, Calendar, Plus } from 'lucide-react';

const CompetencyDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const competency = COMPETENCIES.find(c => c.id === id);

  if (!competency) {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto animate-fade-in">
      {/* Header */}
      <div className="mb-10 border-b border-pink-100 pb-8">
        <div className="flex items-center gap-4 mb-4">
          <div className={`p-4 rounded-2xl ${competency.color} shadow-sm`}>
            <competency.icon size={36} />
          </div>
          <div>
             <h1 className="text-3xl font-bold text-slate-900">{competency.title}</h1>
             <p className="text-medical-600 font-medium">{competency.shortTitle}</p>
          </div>
        </div>
        <p className="text-lg text-slate-600 max-w-3xl leading-relaxed">
          {competency.description}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content Area */}
        <div className="lg:col-span-2 space-y-12">
          
          {/* Evidence Section - THE KEY PORTFOLIO PART */}
          <section>
            <h2 className="text-xl font-bold text-slate-900 mb-6 flex items-center gap-2">
              <Paperclip className="text-medical-600" size={24} />
              Evidence & Artifacts
            </h2>
            
            <div className="grid grid-cols-1 gap-6">
              {/* Render User Evidence */}
              {competency.evidence.map((item) => (
                <div key={item.id} className="bg-white border border-slate-200 rounded-xl overflow-hidden hover:shadow-lg transition-all duration-300 group">
                  <div className="p-5">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex gap-3">
                        <div className={`p-2 rounded-lg ${
                          item.type === 'Certificate' ? 'bg-amber-50 text-amber-600' : 
                          item.type === 'Image' ? 'bg-blue-50 text-blue-600' : 'bg-slate-100 text-slate-600'
                        }`}>
                          {item.type === 'Certificate' ? <Award size={20} /> : 
                           item.type === 'Image' ? <ImageIcon size={20} /> : <FileText size={20} />}
                        </div>
                        <div>
                           <h3 className="font-bold text-slate-900 group-hover:text-medical-600 transition-colors">{item.title}</h3>
                           {item.date && (
                             <div className="flex items-center text-xs text-slate-400 mt-1">
                               <Calendar size={12} className="mr-1" /> {item.date}
                             </div>
                           )}
                        </div>
                      </div>
                      <span className="text-xs font-semibold bg-slate-100 text-slate-500 px-2 py-1 rounded-full uppercase tracking-wide">
                        {item.type}
                      </span>
                    </div>
                    
                    {/* Placeholder for actual image upload if URL is generic, or display if available */}
                    <div className="bg-slate-50 rounded-lg border-2 border-dashed border-slate-200 h-48 mb-4 flex flex-col items-center justify-center relative overflow-hidden group-hover:border-medical-200 transition-colors">
                        {item.imageUrl ? (
                           <img src={item.imageUrl} alt={item.title} className="w-full h-full object-cover" />
                        ) : (
                          <>
                             <ImageIcon className="text-slate-300 mb-2" size={32} />
                             <p className="text-xs text-slate-400">Upload your {item.type.toLowerCase()} here</p>
                          </>
                        )}
                        <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                            <span className="text-white font-medium text-sm">View Full Size</span>
                        </div>
                    </div>

                    <p className="text-sm text-slate-600 leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                </div>
              ))}

              {/* Empty State / Add New Placeholder */}
              <div className="border-2 border-dashed border-slate-200 rounded-xl p-8 flex flex-col items-center justify-center text-center hover:bg-pink-50 hover:border-pink-200 transition-colors cursor-pointer group">
                <div className="bg-slate-50 p-3 rounded-full mb-3 group-hover:bg-white">
                  <Plus className="text-slate-400 group-hover:text-medical-500" size={24} />
                </div>
                <h3 className="text-sm font-semibold text-slate-900">Add New Evidence</h3>
                <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                   {competency.evidencePlaceholder}
                </p>
              </div>
            </div>
          </section>

          {/* Reflection Section */}
          <section>
            <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-2">
              <Quote className="text-medical-600" size={24} />
              Reflection
            </h2>
            <div className="bg-pink-50/50 border border-pink-100 rounded-r-xl border-l-4 border-l-medical-500 p-6 text-slate-700 italic relative">
              <Quote className="absolute top-4 left-4 text-pink-200 -z-10" size={48} />
              "Reflecting on my experiences in {competency.title}, I have come to appreciate... [Click to edit this reflection text. Add your personal thoughts about how the evidence above contributed to your growth as a student at GMU.]"
            </div>
          </section>
        </div>

        {/* Sidebar Concepts */}
        <div className="lg:col-span-1">
          <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-6 sticky top-24">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4 border-b border-slate-100 pb-2">
              Key Competency Concepts
            </h3>
            <ul className="space-y-4">
              {competency.keyConcepts.map((concept, idx) => (
                <li key={idx} className="flex items-start gap-3 text-slate-700 group">
                  <div className="mt-0.5 bg-pink-50 text-medical-600 rounded-full p-0.5">
                    <CheckCircle2 size={14} />
                  </div>
                  <span className="text-sm font-medium group-hover:text-medical-700 transition-colors">{concept}</span>
                </li>
              ))}
            </ul>

            <div className="mt-8 pt-6 border-t border-slate-100">
              <h4 className="text-sm font-bold text-slate-900 mb-2">Development Plan</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                I plan to further develop this competency by seeking more opportunities for complex case management and requesting specific feedback during my next clinical rotation.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CompetencyDetail;