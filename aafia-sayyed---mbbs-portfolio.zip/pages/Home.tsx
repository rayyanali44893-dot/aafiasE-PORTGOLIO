import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Download, Award, Book, Heart, Sparkles } from 'lucide-react';
import { COMPETENCIES } from '../data';

const Home: React.FC = () => {
  return (
    <div className="px-4 sm:px-6 lg:px-8">
      {/* Hero Section */}
      <div className="relative rounded-3xl overflow-hidden mb-12 bg-slate-900 text-white shadow-xl">
        <div className="absolute inset-0 bg-gradient-to-r from-medical-900 to-medical-600 opacity-90 mix-blend-multiply"></div>
        <img 
          src="https://images.unsplash.com/photo-1630325458998-659c25df2008?auto=format&fit=crop&q=80&w=2000" 
          alt="Gulf Medical University Campus" 
          className="absolute inset-0 w-full h-full object-cover opacity-40"
        />
        <div className="relative flex flex-col justify-center px-8 py-20 sm:px-12 sm:py-24">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 text-white text-xs font-medium w-fit mb-6 backdrop-blur-sm border border-white/30">
            <Sparkles size={12} /> MBBS Student Portfolio
          </div>
          <h1 className="text-4xl sm:text-6xl font-bold font-serif mb-6 leading-tight">
            Aafia Sayyed
          </h1>
          <p className="text-lg sm:text-xl text-pink-50 max-w-2xl font-light leading-relaxed">
            Aspiring Medical Professional at Gulf Medical University. <br/>
            Dedicated to evidence-based practice, patient advocacy, and the art of healing.
          </p>
          <div className="mt-8 flex flex-wrap gap-4">
             <a 
              href="#competencies" 
              className="inline-flex items-center px-6 py-3 border border-transparent text-sm font-semibold rounded-full shadow-lg text-medical-900 bg-white hover:bg-pink-50 transition-all transform hover:scale-105"
            >
              Explore Competencies
            </a>
            <button className="inline-flex items-center px-6 py-3 border border-white/40 text-sm font-semibold rounded-full text-white hover:bg-white/10 transition-all backdrop-blur-sm">
              <Download className="mr-2 h-4 w-4" /> Download Resume
            </button>
          </div>
        </div>
      </div>

      {/* About Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 mb-20">
        <div className="lg:col-span-2">
          <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
            <span className="w-10 h-1.5 bg-medical-400 rounded-full"></span>
            About Me
          </h2>
          <div className="prose prose-slate prose-lg text-slate-600 leading-relaxed">
            <p className="mb-4">
              Hello! I am <strong className="text-medical-700">Aafia Sayyed</strong>, a dedicated medical student at Gulf Medical University.
            </p>
            <p className="mb-4">
              This e-portfolio serves as a comprehensive reflection of my journey through medical school. 
              It documents my growth across the key competency frameworks essential for a modern physician. 
              From mastering clinical skills in the simulation lab to advocating for community health on World Diabetes Day, 
              each section here represents a stepping stone in my professional identity formation.
            </p>
            <p>
              I am passionate about bridging the gap between rigorous scientific knowledge and compassionate, patient-centered care.
              My goal is to become a socially accountable leader in the healthcare system.
            </p>
          </div>
        </div>
        
        {/* Quick Stats / Highlights */}
        <div className="bg-white rounded-2xl p-8 border border-slate-100 shadow-lg shadow-pink-100/50 h-fit">
          <h3 className="text-lg font-bold text-slate-900 mb-6 border-b border-slate-100 pb-4">
            Highlights
          </h3>
          <ul className="space-y-6">
            <li className="flex items-start group">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-10 w-10 rounded-full bg-pink-100 text-medical-600 group-hover:bg-medical-600 group-hover:text-white transition-colors">
                  <Award size={20} />
                </div>
              </div>
              <div className="ml-4">
                <p className="text-sm font-bold text-slate-900">Academic Excellence</p>
                <p className="text-xs text-slate-500 mt-0.5">Consistent Dean's List performance</p>
              </div>
            </li>
            <li className="flex items-start group">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-10 w-10 rounded-full bg-rose-100 text-rose-600 group-hover:bg-rose-600 group-hover:text-white transition-colors">
                  <Book size={20} />
                </div>
              </div>
              <div className="ml-4">
                <p className="text-sm font-bold text-slate-900">Research & Inquiry</p>
                <p className="text-xs text-slate-500 mt-0.5">Presented at Fakeeh University Hospital Conference</p>
              </div>
            </li>
            <li className="flex items-start group">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-10 w-10 rounded-full bg-purple-100 text-purple-600 group-hover:bg-purple-600 group-hover:text-white transition-colors">
                  <Heart size={20} />
                </div>
              </div>
              <div className="ml-4">
                <p className="text-sm font-bold text-slate-900">Community Engagement</p>
                <p className="text-xs text-slate-500 mt-0.5">Active volunteer for World Diabetes Day</p>
              </div>
            </li>
          </ul>
        </div>
      </div>

      {/* Competency Grid */}
      <div id="competencies" className="mb-16">
        <div className="text-center mb-12">
           <h2 className="text-3xl font-bold text-slate-900 mb-3">Core Competencies</h2>
           <p className="text-slate-500 max-w-2xl mx-auto">
             Explore my evidence and reflections across the essential roles of a physician.
           </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {COMPETENCIES.map((comp) => (
            <Link 
              key={comp.id} 
              to={`/competency/${comp.id}`}
              className="group relative bg-white border border-slate-200 rounded-2xl p-6 shadow-sm hover:shadow-xl hover:shadow-pink-100/50 transition-all duration-300 hover:-translate-y-1"
            >
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-pink-200 to-transparent rounded-t-2xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
              
              <div className={`inline-flex p-3 rounded-xl ${comp.color} mb-5 group-hover:scale-110 transition-transform duration-300`}>
                <comp.icon size={28} />
              </div>
              
              <h3 className="text-lg font-bold text-slate-900 mb-2 group-hover:text-medical-600 transition-colors">
                {comp.title}
              </h3>
              
              <p className="text-sm text-slate-500 line-clamp-3 mb-6 leading-relaxed">
                {comp.description}
              </p>
              
              <div className="flex items-center text-sm font-semibold text-medical-600 mt-auto border-t border-slate-100 pt-4">
                View Evidence 
                <span className="ml-2 bg-pink-50 rounded-full p-1 group-hover:bg-medical-600 group-hover:text-white transition-colors">
                  <ArrowRight size={12} />
                </span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Home;