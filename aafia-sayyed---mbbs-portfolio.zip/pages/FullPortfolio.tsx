import React from 'react';
import { COMPETENCIES } from '../data';
import { Mail, GraduationCap, MapPin, Phone, Award, Quote, CheckCircle2, Paperclip, ImageIcon, FileText, Printer, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

const FullPortfolio: React.FC = () => {
  
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="bg-white min-h-screen">
      {/* Controls - Hidden when printing */}
      <div className="no-print fixed top-0 left-0 right-0 bg-slate-900 text-white p-4 shadow-md z-50 flex justify-between items-center">
        <Link to="/" className="flex items-center gap-2 text-slate-300 hover:text-white transition-colors">
          <ArrowLeft size={20} /> Back to Website
        </Link>
        <button 
          onClick={handlePrint}
          className="flex items-center gap-2 bg-pink-600 hover:bg-pink-700 text-white px-4 py-2 rounded-lg font-medium transition-colors"
        >
          <Printer size={20} /> Print / Save as PDF
        </button>
      </div>

      <div className="max-w-4xl mx-auto px-8 py-24 print:py-0 print:px-0">
        
        {/* Header Section */}
        <header className="border-b-2 border-slate-900 pb-8 mb-12 text-center">
            <h1 className="text-4xl font-bold text-slate-900 mb-2">Aafia Sayyed</h1>
            <p className="text-xl text-slate-600 mb-6">MBBS Student Portfolio &middot; Gulf Medical University</p>
            
            <div className="flex justify-center gap-6 text-sm text-slate-500">
                <span className="flex items-center gap-1"><Mail size={14}/> aafia.student@uni.edu</span>
                <span className="flex items-center gap-1"><MapPin size={14}/> Ajman, UAE</span>
                <span className="flex items-center gap-1"><GraduationCap size={14}/> Class of 2026</span>
            </div>
        </header>

        {/* Introduction */}
        <section className="mb-16">
            <h2 className="text-2xl font-bold text-slate-900 mb-4">Professional Profile</h2>
            <p className="text-slate-700 leading-relaxed text-justify">
                Dedicated medical student with a strong commitment to evidence-based practice and patient advocacy. 
                This portfolio demonstrates my progression through the core competencies required for modern medical practice, 
                highlighting specific achievements in clinical skills, research, and community engagement.
            </p>
        </section>

        {/* Competencies Loop */}
        <div className="space-y-16">
            {COMPETENCIES.map((comp) => (
                <section key={comp.id} className="break-inside-avoid">
                    <div className="flex items-center gap-3 mb-6 border-b border-slate-200 pb-2">
                        <div className={`p-2 rounded-lg ${comp.color} print:bg-transparent print:text-black print:p-0`}>
                            <comp.icon size={24} />
                        </div>
                        <h2 className="text-2xl font-bold text-slate-900">{comp.title}</h2>
                    </div>
                    
                    <p className="text-slate-600 mb-6 italic">
                        {comp.description}
                    </p>

                    <div className="mb-6">
                        <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-3">Evidence</h3>
                        {comp.evidence.length > 0 ? (
                            <div className="space-y-4">
                                {comp.evidence.map(item => (
                                    <div key={item.id} className="border border-slate-200 rounded-lg p-4 bg-slate-50 print:bg-white print:border-slate-300">
                                        <div className="flex justify-between items-start mb-2">
                                            <h4 className="font-bold text-slate-900">{item.title}</h4>
                                            <span className="text-xs font-medium bg-white border border-slate-200 px-2 py-0.5 rounded text-slate-500 print:hidden">
                                                {item.type}
                                            </span>
                                        </div>
                                        <p className="text-sm text-slate-700 mb-2">{item.description}</p>
                                        {item.date && <p className="text-xs text-slate-500">{item.date}</p>}
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <p className="text-sm text-slate-400 italic">No evidence uploaded yet.</p>
                        )}
                    </div>

                    <div>
                         <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-3">Reflection</h3>
                         <div className="text-sm text-slate-700 border-l-2 border-slate-300 pl-4 py-1">
                             Reflecting on my experiences in {comp.shortTitle}, I have come to appreciate the importance of continuous growth in this area...
                         </div>
                    </div>
                </section>
            ))}
        </div>

        <footer className="mt-24 pt-8 border-t border-slate-200 text-center text-xs text-slate-400">
            Generated from Aafia Sayyed's e-Portfolio on {new Date().toLocaleDateString()}.
        </footer>

      </div>
      
      {/* Print Styles Injection for helper classes */}
      <style>{`
        @media print {
          .no-print { display: none !important; }
          body { background: white; }
          .print\\:py-0 { padding-top: 0 !important; padding-bottom: 0 !important; }
          .print\\:px-0 { padding-left: 0 !important; padding-right: 0 !important; }
          .print\\:bg-transparent { background: transparent !important; }
          .print\\:text-black { color: black !important; }
          .print\\:hidden { display: none !important; }
          .print\\:bg-white { background-color: white !important; }
          .print\\:border-slate-300 { border-color: #cbd5e1 !important; }
        }
      `}</style>
    </div>
  );
};

export default FullPortfolio;